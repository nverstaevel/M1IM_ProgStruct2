def lire_nom()->str:
    nom = input("Veuillez saisir votre nom")
    return nom