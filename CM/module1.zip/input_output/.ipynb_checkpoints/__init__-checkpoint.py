from input_output.entree import lire_nom
from input_output.sortie import dire_bonjour