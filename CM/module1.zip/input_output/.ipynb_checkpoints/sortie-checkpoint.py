def dire_bonjour(nom:str):
    print("Bonjour " + str(nom))