var1 = 0
print(var1)

def helloWorld():
    print("HelloWorld")