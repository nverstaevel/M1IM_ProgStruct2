def helloWorld():
    print("HelloWorld")
    
if __name__ == "__main__":
    # Ceci n'est exécuté qui si le script est lancé comme un programme principal
    # Si il s'agit d'un module, le __name__ serait le nom du module
    helloWorld()
    pass